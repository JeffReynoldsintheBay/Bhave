define(function() {var keywords=[{w:"Notice",p:["p0"]},{w:"Abstract",p:["p1"]},{w:"Closing",p:["p2"]},{w:"the",p:["p2","p4","p18","p29","p34"]},{w:"tool",p:["p2","p4"]},{w:"Exploring",p:["p3"]},{w:"class",p:["p3"]},{w:"relationships",p:["p3"]},{w:"Opening",p:["p4"]},{w:"Close",p:["p5","p8"]},{w:"programs",p:["p5","p8"]},{w:"web",p:["p6","p13","p22","p26","p35"]},{w:"server",p:["p6","p13","p22","p26","p35"]},{w:"database",p:["p7","p10","p16","p21","p24"]},{w:"all",p:["p8"]},{w:"of",p:["p8","p29","p34"]},{w:"your",p:["p8","p13","p17","p21","p22","p27","p29","p31","p34"]},{w:"configure",p:["p9"]},{w:"Configuring",p:["p10","p12","p13","p14"]},{w:"a",p:["p10","p16","p24","p26"]},{w:"hard",p:["p11","p12","p17","p27"]},{w:"drive",p:["p11","p18","p27"]},{w:"storage",p:["p12"]},{w:"devices",p:["p12"]},{w:"troubleshooting",p:["p15","p16","p17"]},{w:"disk",p:["p17"]},{w:"Attach",p:["p18"]},{w:"to",p:["p18"]},{w:"system",p:["p18","p31","p34"]},{w:"Overview",p:["p19"]},{w:"install",p:["p20"]},{w:"Installing",p:["p21","p22"]},{w:"own",p:["p21","p22"]},{w:"maintain",p:["p23"]},{w:"Maintaining",p:["p24","p25","p26","p27"]},{w:"Computer",p:["p28"]},{w:"cover",p:["p28","p29","p34"]},{w:"Replace",p:["p29"]},{w:"system.",p:["p29"]},{w:"Restarting",p:["p30"]},{w:"Restart",p:["p31"]},{w:"Setup",p:["p32"]},{w:"Run",p:["p33"]},{w:"Setup.exe",p:["p33"]},{w:"Remove",p:["p34"]},{w:"Troublshooting",p:["p35"]},{w:"problems",p:["p35"]},{w:"About",p:["p36"]},{w:"us",p:["p36"]},{w:"Hierarchical",p:["p37"]},{w:"edge",p:["p37"]},{w:"bundling",p:["p37"]},{w:"Sample",p:["p38"]},{w:"Appendix",p:["p38"]},{w:"Trademarks",p:["p39"]}];
var ph={};
ph["p0"]=[0];
ph["p1"]=[1];
ph["p2"]=[2, 3, 4];
ph["p3"]=[5, 6, 7];
ph["p4"]=[8, 3, 4];
ph["p5"]=[9, 10];
ph["p6"]=[11, 12];
ph["p7"]=[13];
ph["p8"]=[9, 14, 15, 16, 10];
ph["p9"]=[17];
ph["p30"]=[39];
ph["p10"]=[18, 19, 13];
ph["p32"]=[41];
ph["p31"]=[40, 16, 28];
ph["p12"]=[18, 20, 22, 23];
ph["p34"]=[44, 3, 36, 15, 16, 28];
ph["p11"]=[20, 21];
ph["p33"]=[42, 43];
ph["p14"]=[18];
ph["p36"]=[47, 48];
ph["p13"]=[18, 16, 11, 12];
ph["p35"]=[45, 11, 12, 46];
ph["p16"]=[24, 19, 13];
ph["p38"]=[52, 53];
ph["p15"]=[24];
ph["p37"]=[49, 50, 51];
ph["p18"]=[26, 3, 21, 27, 3, 28];
ph["p17"]=[24, 16, 20, 25];
ph["p39"]=[54];
ph["p19"]=[29];
ph["p21"]=[31, 16, 32, 13];
ph["p20"]=[30];
ph["p23"]=[33];
ph["p22"]=[31, 16, 32, 11, 12];
ph["p25"]=[34];
ph["p24"]=[34, 19, 13];
ph["p27"]=[34, 16, 20, 21];
ph["p26"]=[34, 19, 11, 12];
ph["p29"]=[37, 3, 36, 15, 16, 38];
ph["p28"]=[35, 36];
     return {
         keywords: keywords,
         ph: ph
     }
});
