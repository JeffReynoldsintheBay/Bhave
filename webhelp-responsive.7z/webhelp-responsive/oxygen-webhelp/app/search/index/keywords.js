define(function() {var keywords=[{w:"Closing",p:["p0"]},{w:"the",p:["p0","p2"]},{w:"tool",p:["p0","p2"]},{w:"Exploring",p:["p1"]},{w:"class",p:["p1"]},{w:"relationships",p:["p1"]},{w:"Opening",p:["p2"]},{w:"About",p:["p3"]},{w:"us",p:["p3"]},{w:"Hierarchical",p:["p4"]},{w:"edge",p:["p4"]},{w:"bundling",p:["p4"]}];
var ph={};
ph["p0"]=[0, 1, 2];
ph["p1"]=[3, 4, 5];
ph["p2"]=[6, 1, 2];
ph["p3"]=[7, 8];
ph["p4"]=[9, 10, 11];
     return {
         keywords: keywords,
         ph: ph
     }
});
