/*Maps current topic to its parent: "topicIndex:parentIndex". -1 represents the map.*/
define(function () {
return {27:-1,2:27,26:-1,4:27,3:27};
});