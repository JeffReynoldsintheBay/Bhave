/*Maps current topic to its parent: "topicIndex:parentIndex". -1 represents the map.*/
define(function () {
return {4:-1,0:4,3:-1,2:4,1:4};
});